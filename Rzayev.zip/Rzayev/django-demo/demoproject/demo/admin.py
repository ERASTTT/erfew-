from django.contrib import admin

# Register your models here.
from .models import *

class   ItemInstanseImline(admin.TabularInline
class OrderAdmin(admin.ModelAdmin):
    list_filter = ('status',)
    list_display = ('date', 'user', 'count_product')


admin.site.register(Product)
admin.site.register(Category)
admin.site.register(Order, OrderAdmin)

